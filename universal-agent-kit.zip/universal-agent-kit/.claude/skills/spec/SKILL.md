---
name: spec
description: "Use to write the strategic what/why of a feature - no class names, no file paths, just intent and scope. Triggers: 'write a spec', 'create a ticket for', 'we need a plan for', a task carrying real design decisions."
argument-hint: "<feature description> | <slug> [--priority N] | <ID>"
---

# Strategic Specification Writer

Write a **strategic** spec: the product-level *what* and *why*. No class names, file paths,
line budgets, or framework details - those belong to `/spec-tech`. The discipline of
keeping strategy free of implementation is the whole point: it forces you to agree on the
problem before arguing about the solution.

## Usage

```text
/spec <free-form feature description>      # default: natural language
/spec <slug> [--priority N]                # explicit short name
/spec <ID>                                 # expand an existing Draft in place (a /park stub)
```

**Expanding an existing Draft.** When the argument is the id of a ticket already at `Draft` - a
`/park` stub, or a rough draft `/backlog` selected - keep its id, slug, priority and header tokens,
read its one-line symptom as the problem statement, and run the process below from step 2 on the
same file. Never allocate a second id for a ticket that already has one.

Never refuse input recognizable as a feature description. Only refuse genuinely unusable
input (empty, or a single content-free token like `?`/`help`) - print a short usage hint
and stop. Do not ask the user to pick between candidate slugs; choose one deterministically
and confirm it in the output.

Output file: `<PLAN_DIR>/<ID>_<slug>.md`. Allocate `<ID>` with **this repo's id scheme**
(`docs/SPEC_LIFECYCLE.md` "Adapting it"): a numeric scheme scans `<PLAN_DIR>/` for the highest
existing id and increments (e.g. `T0041` → `T0042`); an external-tracker (`JIRA-123`) or
date-slug scheme allocates the id that way instead. The tactical folder
`<PLAN_DIR>/<ID>_<slug>/` is created later by `/spec-tech`.

## Process

**1 - Parse and normalize.** Derive a kebab-case `slug` from the description (2-5
content-bearing words, ≤ 60 chars). Prefix `bugfix-` for fix/crash wording, `hotfix-` for
urgent/blocker wording. When the input is free-form, keep the user's original phrasing -
§1 must paraphrase *their* problem statement, not a reinterpretation. Default priority 50
(bugfix 90, hotfix 95); `--priority N` (0..100) overrides.

**2 - Read context.** The repo map, architecture doc, build/ops doc, and the existing
feature list. Enough to state the problem accurately and avoid duplicating an existing
capability.

**2.5 - Complexity gate (PRIMITIVE check).** Score the task:

- [ ] ≤ 3 existing files change - no new files
- [ ] No new classes, interfaces, or public types
- [ ] No schema/migration change
- [ ] No new dependency-injection wiring / module
- [ ] No new screen, route, or navigation destination
- [ ] Mechanically deterministic - no deferred design decisions
- [ ] Estimated delta < ~100 lines total

**If ALL pass → PRIMITIVE path** (skip steps 3-7):
1. Allocate the id, write a minimal spec: the template's header block - including
   `**Blocked-by:**` and `**Carried-to:**`, mandatory here too - then `## Problem`, `## Approach`
   (one bullet per file) and `## Done criteria` (one observable check per file). Set
   `Status: In Progress`.
2. Implement directly, then run the narrowest meaningful check from `docs/VALIDATION.md`
   (`<CHECK_CMD>`, or a compile / type-check or a targeted test where the project has them) that
   takes 5 seconds or less. A slower rung waits for the release: record it as
   `NOT APPLICABLE - release tier` and list its command as a `RELEASE` item ("The ladder" there). A
   primitive still proves itself - do not set `Implemented` over a red or unrun check.
3. If acceptance includes manual testing, insert the verification tags
   (`docs/SPEC_LIFECYCLE.md`, "Verification tags"), add a `## Manual checks` section with one
   `[ ]` line per thing a human must see, and set `Status: BlockNeedUserTest`. Otherwise
   `Status: Implemented`.
4. Report: `<ID> - Primitive. Implemented directly. Status: <status>.`

**If ANY criterion fails → COMPLEX path:** continue.

**3 - Determine tier.** A rough size label for triage: `Quick Win` · `Easy` · `Moderate` ·
`Strategic` · `Security/Compliance (urgent)`. Tier is a human-facing triage hint only - no skill
gates on it (`/backlog` selects by `Priority`), so keep it approximate.

**4 - Allocate the id** before any file write (per the repo's id scheme - scan-and-increment
for a numeric scheme; otherwise follow that scheme).

**5 - Write the strategic file** using the template below.

**5.1 - Owner inputs (Approval gate).** Fill §3.3 with only the bullets that match the
spec's actual scope - do not pad with `n/a` lines to look thorough. The one universally
required field is **Related tickets** - prose, for a human. A dependency a *skill* must act on
goes in the header's `**Blocked-by:**` token as well; an id in prose is a mention, an id in the
token is a claim (`docs/SPEC_LIFECYCLE.md`, "Two literal tokens"). Emit a bullet only when its tag
is triggered by the slug or the §1/§3.2 text, for example:
- user-facing wording touched → **Copy/tone policy**
- data/schema touched → **Data compatibility**
- performance-critical → **Performance budget**
- platform/version-bound → **Platform constraints**
- localization touched → **Localization**
- any tag matched → also **Validation level** and **Owner sign-off**

**6 - Approve.** Flip `Status: Draft → Approved` in the file. (The style gate - lists over
tables, one idea per bullet, no section summaries - is enforced *here*, at approval, not while
drafting. A Draft may stay rough.)

**7 - Auto-chain to `/spec-tech`.** Immediately invoke `/spec-tech <ID>` unless a §6
research item is `Open` and marked as required before implementation - then list those and
ask whether to proceed.

**Chat output:** `<ID> <slug> - Tier T, Priority P. Status: Approved. -> Running /spec-tech..`

## Status lifecycle

The gate table - which status each skill requires and produces, the full flow, and every block
state - is defined once in `docs/SPEC_LIFECYCLE.md`; this skill does not restate it. This skill's
row: requires none (allocates an id) or an existing `Draft` (expands it in place), produces
`Approved` (or `Implemented` / `BlockNeedUserTest` for a primitive), auto-chains to `/spec-tech`
for a complex spec. When `/spec` records a
dependency it sets `BlockByOtherTask` **and** names the blocker in the header's `**Blocked-by:**`
token - §10 prose is for the human, the token is what `/backlog` reads. Every transition into a
`Block*` status carries a one-line note on the status line, after ` - ` - what must be tested,
or what the blocker is and what resolves it.

## Template

The strategic template lives in [`references/TEMPLATE.md`](references/TEMPLATE.md). Read it before
step 5; a PRIMITIVE spec uses only its header block plus the three sections named in step 2.5.

## Constraints

- §5: architectural roles only - no class names, file paths, line budgets, schema versions,
  DI modules.
- §11: observable outcomes only.
- §6 and §7 are mandatory even if trivial - write an explicit "none" rather than omitting.
- The header's `**Blocked-by:**` and `**Carried-to:**` tokens are mandatory too, and `none` is a
  value - an absent line is not. `/backlog` reads `Blocked-by`; `/spec-check` reads `Carried-to`
  when it decides whether §6 is closed. Never infer either from §3.3 or §10 prose.
- Do not duplicate an existing feature-doc entry.
- The style + completeness gate runs only at the `Draft -> Approved` flip; a Draft may keep
  rough phrasing.
